import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { 
  Gift, 
  Ticket, 
  Download, 
  Star, 
  CheckCircle, 
  XCircle,
  Clock,
  DollarSign,
  UserPlus,
  FileText,
  Percent,
  Smartphone,
  TrendingUp
} from 'lucide-react';
import { useAuth } from './AuthContext';

export interface Notification {
  id: string;
  type: 'promotion' | 'coupon' | 'app_update' | 'loyalty_reward' | 'special_offer' | 'new_feature' | 'customer_registered' | 'invoice_created' | 'invoice_paid' | 'invoice_overdue' | 'low_stock' | 'payment_received' | 'payment_failed' | 'system_alert';
  title: string;
  message: string;
  timestamp: Date;
  isRead: boolean;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  data?: any;
  actionUrl?: string;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  addNotification: (notification: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  removeNotification: (id: string) => void;
  clearAll: () => void;
  soundEnabled: boolean;
  toggleSound: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const { user } = useAuth();
  
  // Referências para os elementos de áudio
  const cashSoundRef = useRef<HTMLAudioElement | null>(null);
  const registerSoundRef = useRef<HTMLAudioElement | null>(null);

  // Inicializar elementos de áudio
  useEffect(() => {
    // Criar elementos de áudio
    cashSoundRef.current = new Audio('/sounds/cash.mp3');
    registerSoundRef.current = new Audio('/sounds/register.mp3');

    // Configurar propriedades dos áudios
    if (cashSoundRef.current) {
      cashSoundRef.current.preload = 'auto';
      cashSoundRef.current.volume = 0.7;
    }
    
    if (registerSoundRef.current) {
      registerSoundRef.current.preload = 'auto';
      registerSoundRef.current.volume = 0.7;
    }

    // Carregar preferência de som do localStorage
    const savedSoundPreference = localStorage.getItem('notificationSoundEnabled');
    if (savedSoundPreference !== null) {
      setSoundEnabled(JSON.parse(savedSoundPreference));
    }

    // Cleanup
    return () => {
      if (cashSoundRef.current) {
        cashSoundRef.current.pause();
        cashSoundRef.current = null;
      }
      if (registerSoundRef.current) {
        registerSoundRef.current.pause();
        registerSoundRef.current = null;
      }
    };
  }, []);

  // Função para reproduzir som
  const playSound = async (soundType: 'cash' | 'register') => {
    if (!soundEnabled) return;

    try {
      let audioElement: HTMLAudioElement | null = null;
      
      if (soundType === 'cash' && cashSoundRef.current) {
        audioElement = cashSoundRef.current;
      } else if (soundType === 'register' && registerSoundRef.current) {
        audioElement = registerSoundRef.current;
      }

      if (audioElement) {
        // Reset audio to beginning
        audioElement.currentTime = 0;
        
        // Play the sound
        const playPromise = audioElement.play();
        
        if (playPromise !== undefined) {
          await playPromise;
        }
      }
    } catch (error) {
      console.warn('Erro ao reproduzir som de notificação:', error);
      // Se falhar, tenta criar um novo elemento de áudio
      try {
        const fallbackAudio = new Audio(soundType === 'cash' ? '/sounds/cash.mp3' : '/sounds/register.mp3');
        fallbackAudio.volume = 0.7;
        await fallbackAudio.play();
      } catch (fallbackError) {
        console.warn('Erro no fallback de áudio:', fallbackError);
      }
    }
  };

  // Funções auxiliares para gerar dados simulados
  const generateRandomAppName = () => {
    const apps = ['MeuApp Recarga', 'SuperRecarga', 'RecargaMax', 'BasicApp', 'MidApp', 'ProApp', 'PremiumApp', 'UltraApp'];
    return apps[Math.floor(Math.random() * apps.length)];
  };

  const generateRandomPromotion = () => {
    const promotions = [
      'Desconto de 20% em todas as recargas acima de R$ 50',
      'Compre 2 recargas e ganhe 1 grátis',
      'Cashback de 10% em recargas via PIX',
      'Promoção relâmpago: 30% OFF por tempo limitado',
      'Black Friday: Até 50% de desconto em planos premium',
      'Recarga dupla: Pague R$ 30 e ganhe R$ 60 de crédito',
      'Oferta especial: 3 meses de internet grátis',
      'Super desconto: Planos a partir de R$ 15'
    ];
    return promotions[Math.floor(Math.random() * promotions.length)];
  };

  const generateRandomCoupon = () => {
    const coupons = [
      { code: 'SAVE20', discount: '20%', description: 'Desconto em qualquer recarga' },
      { code: 'FIRST10', discount: '10%', description: 'Para novos clientes' },
      { code: 'MEGA30', discount: '30%', description: 'Válido até amanhã' },
      { code: 'VIP15', discount: '15%', description: 'Clientes VIP' },
      { code: 'FLASH25', discount: '25%', description: 'Promoção relâmpago' },
      { code: 'BONUS50', discount: 'R$ 50', description: 'Bônus em recargas acima de R$ 100' }
    ];
    return coupons[Math.floor(Math.random() * coupons.length)];
  };

  const generateRandomAppUpdate = () => {
    const updates = [
      { app: generateRandomAppName(), version: '2.1.0', feature: 'Nova interface mais intuitiva' },
      { app: generateRandomAppName(), version: '1.8.5', feature: 'Correções de bugs e melhorias' },
      { app: generateRandomAppName(), version: '3.0.0', feature: 'Pagamento via PIX instantâneo' },
      { app: generateRandomAppName(), version: '2.5.2', feature: 'Histórico de compras melhorado' },
      { app: generateRandomAppName(), version: '1.9.1', feature: 'Notificações push personalizadas' },
      { app: generateRandomAppName(), version: '2.3.0', feature: 'Modo escuro disponível' }
    ];
    return updates[Math.floor(Math.random() * updates.length)];
  };

  const generateRandomLoyaltyReward = () => {
    const rewards = [
      'Você ganhou 100 pontos de fidelidade!',
      'Parabéns! Você subiu para o nível Prata',
      'Resgate disponível: 500 pontos = R$ 25 de desconto',
      'Bônus especial: 200 pontos adicionados à sua conta',
      'Você está a 50 pontos do nível Ouro!',
      'Oferta exclusiva para clientes Platina'
    ];
    return rewards[Math.floor(Math.random() * rewards.length)];
  };

  // Simular notificações em tempo real baseadas no tipo de usuário
  useEffect(() => {
    if (!user) return;

    const interval = setInterval(() => {
      let notificationTypes: any[] = [];

      // Notificações específicas para clientes
      if (user.role === 'customer') {
        const customerNotifications = [
          {
            type: 'promotion' as const,
            title: '🎉 Nova Promoção Disponível!',
            message: generateRandomPromotion(),
            priority: 'medium' as const,
            data: { promotionId: `promo-${Date.now()}` }
          },
          {
            type: 'coupon' as const,
            title: '🎫 Cupom Exclusivo para Você!',
            message: (() => {
              const coupon = generateRandomCoupon();
              return `Use o cupom ${coupon.code} e ganhe ${coupon.discount} de desconto! ${coupon.description}`;
            })(),
            priority: 'high' as const,
            data: { couponCode: generateRandomCoupon().code }
          },
          {
            type: 'app_update' as const,
            title: '📱 Atualização Disponível',
            message: (() => {
              const update = generateRandomAppUpdate();
              return `${update.app} v${update.version} - ${update.feature}`;
            })(),
            priority: 'low' as const,
            data: { appName: generateRandomAppName(), version: '2.1.0' }
          },
          {
            type: 'loyalty_reward' as const,
            title: '⭐ Programa de Fidelidade',
            message: generateRandomLoyaltyReward(),
            priority: 'medium' as const,
            data: { points: Math.floor(Math.random() * 500) + 50 }
          },
          {
            type: 'special_offer' as const,
            title: '🔥 Oferta Especial',
            message: `Oferta limitada: ${generateRandomPromotion()} - Válida por 24h!`,
            priority: 'high' as const,
            data: { expiresIn: '24h' }
          },
          {
            type: 'new_feature' as const,
            title: '✨ Nova Funcionalidade',
            message: `Novidade no ${generateRandomAppName()}: Agora você pode agendar suas recargas!`,
            priority: 'low' as const,
            data: { feature: 'scheduled_recharge' }
          }
        ];
        notificationTypes = customerNotifications;
      } else {
        // Notificações administrativas para outros tipos de usuário
        const adminNotifications = [
          {
            type: 'customer_registered' as const,
            title: 'Novo Cliente Cadastrado',
            message: `Cliente ${generateRandomName()} foi cadastrado no sistema`,
            priority: 'medium' as const,
            data: { customerId: `customer-${Date.now()}` }
          },
          {
            type: 'invoice_paid' as const,
            title: 'Fatura Paga',
            message: `Fatura #${Math.floor(Math.random() * 10000)} foi paga com sucesso - R$ ${(Math.random() * 500 + 50).toFixed(2)}`,
            priority: 'low' as const,
            data: { invoiceId: `invoice-${Date.now()}`, amount: Math.floor(Math.random() * 500) + 50 }
          },
          {
            type: 'payment_received' as const,
            title: 'Pagamento Recebido',
            message: `Pagamento de R$ ${(Math.random() * 500 + 50).toFixed(2)} foi processado com sucesso`,
            priority: 'low' as const,
            data: { amount: Math.random() * 500 + 50, paymentId: `pay-${Date.now()}` }
          },
          {
            type: 'low_stock' as const,
            title: 'Códigos Acabando',
            message: `Apenas ${Math.floor(Math.random() * 10) + 1} códigos restantes para ${getRandomOperator()} R$ ${getRandomValue()}`,
            priority: 'urgent' as const,
            data: { operator: getRandomOperator(), value: getRandomValue(), remaining: Math.floor(Math.random() * 10) + 1 }
          }
        ];
        notificationTypes = adminNotifications;
      }

      // Adicionar notificação aleatória a cada 8-20 segundos
      const randomNotification = notificationTypes[Math.floor(Math.random() * notificationTypes.length)];
      
      if (Math.random() > 0.6) { // 40% de chance a cada intervalo
        addNotification(randomNotification);
      }
    }, 12000); // Verificar a cada 12 segundos

    // Adicionar algumas notificações iniciais baseadas no tipo de usuário
    setTimeout(() => {
      if (user.role === 'customer') {
        addNotification({
          type: 'promotion',
          title: '🎉 Bem-vindo! Oferta Especial',
          message: 'Ganhe 20% de desconto na sua primeira recarga acima de R$ 30',
          priority: 'high',
          data: { couponCode: 'WELCOME20' }
        });
      } else {
        addNotification({
          type: 'customer_registered',
          title: 'Novo Cliente Cadastrado',
          message: 'Maria Silva foi cadastrada no sistema',
          priority: 'medium',
          data: { customerId: 'customer-001' }
        });
      }
    }, 1000);

    setTimeout(() => {
      if (user.role === 'customer') {
        addNotification({
          type: 'app_update',
          title: '📱 Atualização Disponível',
          message: 'MeuApp Recarga v2.1.0 - Nova interface mais intuitiva e pagamento PIX instantâneo',
          priority: 'low',
          data: { appName: 'MeuApp Recarga', version: '2.1.0' }
        });
      } else {
        addNotification({
          type: 'invoice_paid',
          title: 'Fatura Paga',
          message: 'Fatura #1234 foi paga com sucesso - R$ 150,00',
          priority: 'low',
          data: { invoiceId: 'invoice-1234', amount: 150 }
        });
      }
    }, 3000);

    setTimeout(() => {
      if (user.role === 'customer') {
        addNotification({
          type: 'coupon',
          title: '🎫 Cupom Exclusivo!',
          message: 'Use o cupom MEGA30 e ganhe 30% de desconto! Válido até amanhã',
          priority: 'high',
          data: { couponCode: 'MEGA30', discount: '30%' }
        });
      } else {
        addNotification({
          type: 'low_stock',
          title: 'Códigos Acabando',
          message: 'Apenas 3 códigos restantes para Vivo R$ 30',
          priority: 'urgent',
          data: { operator: 'Vivo', value: 30, remaining: 3 }
        });
      }
    }, 5000);

    setTimeout(() => {
      if (user.role === 'customer') {
        addNotification({
          type: 'loyalty_reward',
          title: '⭐ Parabéns!',
          message: 'Você ganhou 150 pontos de fidelidade e subiu para o nível Prata!',
          priority: 'medium',
          data: { points: 150, newLevel: 'silver' }
        });
      } else {
        addNotification({
          type: 'payment_failed',
          title: 'Falha no Pagamento',
          message: 'Pagamento de R$ 85,00 foi rejeitado - Cartão sem limite',
          priority: 'high',
          data: { amount: 85, reason: 'Cartão sem limite' }
        });
      }
    }, 7000);

    return () => clearInterval(interval);
  }, [user]);

  const generateRandomName = () => {
    const names = ['João Silva', 'Maria Santos', 'Pedro Costa', 'Ana Oliveira', 'Carlos Lima', 'Fernanda Souza', 'Ricardo Alves', 'Juliana Pereira', 'Bruno Martins', 'Camila Rodrigues'];
    return names[Math.floor(Math.random() * names.length)];
  };

  const getRandomOperator = () => {
    const operators = ['Vivo', 'Claro', 'TIM', 'Oi'];
    return operators[Math.floor(Math.random() * operators.length)];
  };

  const getRandomValue = () => {
    const values = [15, 20, 30, 50, 100];
    return values[Math.floor(Math.random() * values.length)];
  };

  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `notification-${Date.now()}-${Math.random()}`,
      timestamp: new Date(),
      isRead: false
    };

    setNotifications(prev => [newNotification, ...prev].slice(0, 100)); // Manter apenas 100 notificações

    // 🔊 REPRODUZIR SOM BASEADO NO TIPO DE NOTIFICAÇÃO
    if (soundEnabled) {
      // Som de cash para promoções e cupons (coisas boas para o cliente)
      if (notification.type === 'promotion' || 
          notification.type === 'coupon' || 
          notification.type === 'special_offer' ||
          notification.type === 'loyalty_reward' ||
          notification.type === 'invoice_paid' || 
          notification.type === 'payment_received') {
        playSound('cash');
      }
      // Som de registro para atualizações e novos recursos
      else if (notification.type === 'app_update' || 
               notification.type === 'new_feature' ||
               notification.type === 'customer_registered') {
        playSound('register');
      }
    }

    // Mostrar notificação do navegador se permitido
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(newNotification.title, {
          body: newNotification.message,
          icon: '/vite.svg',
          badge: '/vite.svg',
          tag: newNotification.id,
          requireInteraction: newNotification.priority === 'urgent',
          silent: !soundEnabled // Se som está desabilitado, notificação será silenciosa
        });
      } catch (error) {
        console.warn('Erro ao mostrar notificação do navegador:', error);
      }
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(notification => 
      notification.id === id ? { ...notification, isRead: true } : notification
    ));
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(notification => ({ ...notification, isRead: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(notification => notification.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const toggleSound = () => {
    const newSoundEnabled = !soundEnabled;
    setSoundEnabled(newSoundEnabled);
    localStorage.setItem('notificationSoundEnabled', JSON.stringify(newSoundEnabled));
    
    // Tocar som de teste quando ativar
    if (newSoundEnabled) {
      playSound('cash');
    }
  };

  // Solicitar permissão para notificações do navegador
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          console.log('Permissão para notificações concedida');
        }
      });
    }
  }, []);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      addNotification,
      markAsRead,
      markAllAsRead,
      removeNotification,
      clearAll,
      soundEnabled,
      toggleSound
    }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const getNotificationIcon = (type: Notification['type']) => {
  switch (type) {
    case 'promotion':
    case 'special_offer':
      return Gift;
    case 'coupon':
      return Ticket;
    case 'app_update':
      return Download;
    case 'loyalty_reward':
      return Star;
    case 'new_feature':
      return Smartphone;
    case 'customer_registered':
      return UserPlus;
    case 'invoice_created':
      return FileText;
    case 'invoice_paid':
      return CheckCircle;
    case 'invoice_overdue':
      return Clock;
    case 'low_stock':
      return TrendingUp;
    case 'payment_received':
      return DollarSign;
    case 'payment_failed':
      return XCircle;
    case 'system_alert':
      return Clock;
    default:
      return Clock;
  }
};

export const getNotificationColor = (type: Notification['type'], priority: Notification['priority']) => {
  if (priority === 'urgent') return 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-400';
  if (priority === 'high') return 'text-orange-600 bg-orange-100 dark:bg-orange-900/20 dark:text-orange-400';
  
  switch (type) {
    case 'promotion':
    case 'special_offer':
      return 'text-purple-600 bg-purple-100 dark:bg-purple-900/20 dark:text-purple-400';
    case 'coupon':
      return 'text-pink-600 bg-pink-100 dark:bg-pink-900/20 dark:text-pink-400';
    case 'app_update':
    case 'new_feature':
      return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400';
    case 'loyalty_reward':
      return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 dark:text-yellow-400';
    case 'customer_registered':
      return 'text-blue-600 bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400';
    case 'invoice_created':
      return 'text-purple-600 bg-purple-100 dark:bg-purple-900/20 dark:text-purple-400';
    case 'invoice_paid':
    case 'payment_received':
      return 'text-green-600 bg-green-100 dark:bg-green-900/20 dark:text-green-400';
    case 'invoice_overdue':
    case 'payment_failed':
      return 'text-red-600 bg-red-100 dark:bg-red-900/20 dark:text-red-400';
    case 'low_stock':
      return 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/20 dark:text-yellow-400';
    case 'system_alert':
      return 'text-orange-600 bg-orange-100 dark:bg-orange-900/20 dark:text-orange-400';
    default:
      return 'text-gray-600 bg-gray-100 dark:bg-gray-700 dark:text-gray-300';
  }
};