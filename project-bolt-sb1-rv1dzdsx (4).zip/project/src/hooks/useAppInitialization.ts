import { useState, useEffect } from 'react';
import { useSupabaseRechargeSystem } from './useSupabaseRechargeSystem';
import { useSupabaseCustomers } from './useSupabaseCustomers';
import { useSupabaseResellers } from './useSupabaseResellers';
import { useSupabaseMessageTemplates } from './useSupabaseMessageTemplates';
import { useAuth } from '../contexts/AuthContext';

export const useAppInitialization = () => {
  const [isInitializing, setIsInitializing] = useState(true);
  const { user } = useAuth();

  // Initialize all data hooks but don't trigger their auto-loading
  const rechargeSystem = useSupabaseRechargeSystem();
  const customersSystem = useSupabaseCustomers();
  const resellersSystem = useSupabaseResellers();
  const templatesSystem = useSupabaseMessageTemplates();

  // Centralized initialization function
  useEffect(() => {
    const initializeApp = async () => {
      // If no user is logged in, set isInitializing to false immediately
      // This is the key fix to prevent the loading screen from getting stuck
      if (!user) {
        setIsInitializing(false);
        return;
      }

      setIsInitializing(true);
      console.log('🚀 Iniciando carregamento centralizado de dados...');
      
      try {
        // Load data in parallel using Promise.all
        await Promise.all([
          rechargeSystem.fetchPlans(),
          rechargeSystem.fetchCodes(),
          rechargeSystem.fetchPurchases(),
          customersSystem.fetchCustomers(),
          resellersSystem.fetchResellers(),
          templatesSystem.fetchMessageTemplates()
        ]);
        
        console.log('✅ Carregamento de dados concluído com sucesso');
      } catch (error) {
        console.error('❌ Erro ao carregar dados:', error);
      } finally {
        setIsInitializing(false);
      }
    };

    initializeApp();
  }, [user]);

  return {
    isLoading: isInitializing,
    
    // RechargeSystem data and functions
    codes: rechargeSystem.codes,
    plans: rechargeSystem.plans,
    pendingDeliveries: rechargeSystem.pendingDeliveries,
    allPurchases: rechargeSystem.allPurchases,
    importCodes: rechargeSystem.importCodes,
    assignCodeToPurchase: rechargeSystem.assignCodeToPurchase,
    checkAndSendExpiryReminders: rechargeSystem.checkAndSendExpiryReminders,
    addPendingCodeDelivery: rechargeSystem.addPendingCodeDelivery,
    getStats: rechargeSystem.getStats,
    addPlan: rechargeSystem.addPlan,
    editPlan: rechargeSystem.editPlan,
    deletePlan: rechargeSystem.deletePlan,
    
    // Customers data and functions
    customers: customersSystem.customers,
    addCustomer: customersSystem.addCustomer,
    editCustomer: customersSystem.editCustomer,
    deleteCustomer: customersSystem.deleteCustomer,
    
    // Resellers data and functions
    resellers: resellersSystem.resellers,
    addReseller: resellersSystem.addReseller,
    editReseller: resellersSystem.editReseller,
    promoteToMaster: resellersSystem.promoteToMaster,
    deleteReseller: resellersSystem.deleteReseller,
    
    // Message templates data and functions
    messageTemplates: templatesSystem.messageTemplates,
    addTemplate: templatesSystem.addTemplate,
    editTemplate: templatesSystem.editTemplate,
    deleteTemplate: templatesSystem.deleteTemplate,
    testTemplate: templatesSystem.testTemplate
  };
};