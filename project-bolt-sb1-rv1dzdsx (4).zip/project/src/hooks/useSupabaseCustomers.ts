import { useState } from 'react';
import { supabase, handleSupabaseError } from '../lib/supabase';
import { Customer, Purchase, Invoice } from '../types';

export const useSupabaseCustomers = () => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch customers from Supabase
  const fetchCustomers = async () => {
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('customers')
        .select(`
          *,
          purchases:purchases(*),
          invoices:invoices(*)
        `)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching customers:', error);
        throw new Error(handleSupabaseError(error));
      }

      const formattedCustomers: Customer[] = data.map(customer => ({
        id: customer.id,
        name: customer.name,
        email: customer.email,
        phone: customer.phone,
        cpf: customer.cpf,
        points: customer.points,
        isActive: customer.is_active,
        createdAt: new Date(customer.created_at),
        resellerId: customer.reseller_id,
        loyaltyLevel: customer.loyalty_level as Customer['loyaltyLevel'],
        totalSpent: customer.total_spent,
        purchases: customer.purchases?.map((purchase: any) => ({
          id: purchase.id,
          customerId: purchase.customer_id,
          planId: purchase.plan_id,
          rechargeCode: purchase.recharge_code,
          amount: purchase.amount,
          status: purchase.status as Purchase['status'],
          paymentMethod: purchase.payment_method as Purchase['paymentMethod'],
          paymentId: purchase.payment_id,
          createdAt: new Date(purchase.created_at),
          approvedAt: purchase.approved_at ? new Date(purchase.approved_at) : undefined,
          expiresAt: new Date(purchase.expires_at),
          notificationsSent: [],
          resellerId: purchase.reseller_id,
          commission: purchase.commission as Purchase['commission'],
          codeDeliveryFailureReason: purchase.code_delivery_failure_reason || undefined,
          assignedCodeId: purchase.assigned_code_id || undefined,
          customerData: purchase.customer_data as Purchase['customerData'],
          expiryReminders: purchase.expiry_reminders as Purchase['expiryReminders']
        })) || [],
        invoices: customer.invoices?.map((invoice: any) => ({
          id: invoice.id,
          customerId: invoice.customer_id,
          purchaseId: invoice.purchase_id,
          amount: invoice.amount,
          status: invoice.status as Invoice['status'],
          dueDate: new Date(invoice.due_date),
          paidAt: invoice.paid_at ? new Date(invoice.paid_at) : undefined,
          createdAt: new Date(invoice.created_at)
        })) || []
      }));

      setCustomers(formattedCustomers);
      setIsLoading(false);
    } catch (error) {
      console.error('Error in fetchCustomers:', error);
      setIsLoading(false);
      throw error;
    }
  };

  // Add new customer
  const addCustomer = async (customerData: Omit<Customer, 'id' | 'createdAt' | 'purchases' | 'invoices'>) => {
    try {
      const { data, error } = await supabase
        .from('customers')
        .insert({
          name: customerData.name,
          email: customerData.email,
          phone: customerData.phone,
          cpf: customerData.cpf,
          points: customerData.points || 0,
          is_active: customerData.isActive,
          reseller_id: customerData.resellerId,
          loyalty_level: customerData.loyaltyLevel,
          total_spent: customerData.totalSpent || 0
        })
        .select()
        .single();

      if (error) {
        console.error('Error adding customer:', error);
        throw new Error(handleSupabaseError(error));
      }

      // Refresh customers list
      await fetchCustomers();
      return data;
    } catch (error) {
      console.error('Error in addCustomer:', error);
      throw error;
    }
  };

  // Edit customer
  const editCustomer = async (id: string, customerData: Partial<Customer>) => {
    try {
      const updateData: any = {};
      
      if (customerData.name !== undefined) updateData.name = customerData.name;
      if (customerData.email !== undefined) updateData.email = customerData.email;
      if (customerData.phone !== undefined) updateData.phone = customerData.phone;
      if (customerData.cpf !== undefined) updateData.cpf = customerData.cpf;
      if (customerData.points !== undefined) updateData.points = customerData.points;
      if (customerData.isActive !== undefined) updateData.is_active = customerData.isActive;
      if (customerData.resellerId !== undefined) updateData.reseller_id = customerData.resellerId;
      if (customerData.loyaltyLevel !== undefined) updateData.loyalty_level = customerData.loyaltyLevel;
      if (customerData.totalSpent !== undefined) updateData.total_spent = customerData.totalSpent;

      const { error } = await supabase
        .from('customers')
        .update(updateData)
        .eq('id', id);

      if (error) {
        console.error('Error editing customer:', error);
        throw new Error(handleSupabaseError(error));
      }

      // Refresh customers list
      await fetchCustomers();
    } catch (error) {
      console.error('Error in editCustomer:', error);
      throw error;
    }
  };

  // Delete customer
  const deleteCustomer = async (id: string) => {
    try {
      const { error } = await supabase
        .from('customers')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting customer:', error);
        throw new Error(handleSupabaseError(error));
      }

      // Refresh customers list
      await fetchCustomers();
    } catch (error) {
      console.error('Error in deleteCustomer:', error);
      throw error;
    }
  };

  return {
    customers,
    isLoading,
    addCustomer,
    editCustomer,
    deleteCustomer,
    fetchCustomers
  };
};